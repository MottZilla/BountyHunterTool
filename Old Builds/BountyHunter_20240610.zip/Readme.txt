Bounty Hunter Tool - By MottZilla

This tool is for randomly picking 5 Targets for Bounty Hunter and derivative presets.

How to Use: First generate your Bounty Hunter or derivative seed to a BIN file.
Start BountyHunter tool. Select options as desired. Click Patch ISO.

Options:
* Sprinkle Other Relics - Relics besides the Vlads will be distributed among enemies as a bonus.
* Turbo Item Drop Rates - The drop rate on all enemy drops is increased so you'll get more stuff.
* Target Confirmed - Select this when playing the Target Confirmed preset.
* Hitman Mode - Select this when playing the Hitman preset.
* Generate PPF - Creates a PPF to share or store for later. This requires having a copy of the
 original track 1 BIN in the folder with the program named SotN_PSX.org

Richter Bounty Hunter Note:
If you are generating a Richter Bounty Hunter seed you should generate the seed with the rando
and then patch it with SotN_AR for Richter Rando. Finally patch it with Bounty Hunter. This will
result in the PPF created by Bounty Hunter Tool to have all the patch data.